import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { desc } from "drizzle-orm";

// GET /api/chat?limit=50  — get recent messages
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const limit = Math.min(parseInt(searchParams.get("limit") ?? "50"), 100);

    const messages = await db
      .select()
      .from(chatMessages)
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);

    return NextResponse.json(messages.reverse());
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/chat  — send a message
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { playerId, username, message } = body;

    if (!playerId || !username || !message) {
      return NextResponse.json(
        { error: "playerId, username, and message required" },
        { status: 400 }
      );
    }

    if (typeof message !== "string" || message.trim().length === 0) {
      return NextResponse.json(
        { error: "Message cannot be empty" },
        { status: 400 }
      );
    }

    if (message.trim().length > 200) {
      return NextResponse.json(
        { error: "Message too long (max 200 chars)" },
        { status: 400 }
      );
    }

    const [msg] = await db
      .insert(chatMessages)
      .values({
        playerId,
        username,
        message: message.trim(),
      })
      .returning();

    return NextResponse.json(msg, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
