import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { players, buildingTicks } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { BUILDING_MAP, isBuildingUnlocked } from "@/lib/buildings-data";

// POST /api/economy/buy  — purchase a building
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { playerId, buildingId } = body;

    if (!playerId || !buildingId) {
      return NextResponse.json(
        { error: "playerId and buildingId required" },
        { status: 400 }
      );
    }

    const def = BUILDING_MAP[buildingId];
    if (!def) {
      return NextResponse.json(
        { error: "Unknown building" },
        { status: 400 }
      );
    }

    const [player] = await db
      .select()
      .from(players)
      .where(eq(players.id, playerId));

    if (!player) {
      return NextResponse.json({ error: "Player not found" }, { status: 404 });
    }

    const ownedBuildings = (player.ownedBuildings as string[]) ?? [];
    const buildingLevels = (player.buildingLevels as Record<string, number>) ?? {};

    // Check if already owned
    if (ownedBuildings.includes(buildingId)) {
      return NextResponse.json(
        { error: "Building already owned" },
        { status: 400 }
      );
    }

    // Check unlock requirement
    if (!isBuildingUnlocked(def, ownedBuildings)) {
      return NextResponse.json(
        { error: "Building not unlocked yet" },
        { status: 400 }
      );
    }

    // Check coins
    const currentCoins = player.coins ?? 0;
    if (currentCoins < def.cost) {
      return NextResponse.json(
        { error: `Not enough coins. Need ${def.cost}, have ${currentCoins}` },
        { status: 400 }
      );
    }

    const newCoins = currentCoins - def.cost;
    const newOwned = [...ownedBuildings, buildingId];
    const newLevels = { ...buildingLevels, [buildingId]: 1 };
    const now = new Date();

    const [updated] = await db
      .update(players)
      .set({
        coins: newCoins,
        ownedBuildings: newOwned,
        buildingLevels: newLevels,
        lastSavedAt: now,
      })
      .where(eq(players.id, playerId))
      .returning();

    // Initialize building tick
    const [existingTick] = await db
      .select()
      .from(buildingTicks)
      .where(
        and(
          eq(buildingTicks.playerId, playerId),
          eq(buildingTicks.buildingId, buildingId)
        )
      );

    if (!existingTick) {
      await db.insert(buildingTicks).values({
        playerId,
        buildingId,
        lastTickAt: now,
      });
    }

    return NextResponse.json({
      coins: updated.coins,
      ownedBuildings: updated.ownedBuildings,
      buildingLevels: updated.buildingLevels,
      purchased: buildingId,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
