import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { players } from "@/db/schema";
import { eq } from "drizzle-orm";

const TAP_AMOUNT = 10;
const TAP_COOLDOWN_MS = 500; // prevent spam — max 2 taps/sec

// POST /api/economy/earn  — tap to earn coins
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { playerId } = body;

    if (!playerId) {
      return NextResponse.json({ error: "playerId required" }, { status: 400 });
    }

    const [player] = await db
      .select()
      .from(players)
      .where(eq(players.id, playerId));

    if (!player) {
      return NextResponse.json({ error: "Player not found" }, { status: 404 });
    }

    // Rate-limit check
    const now = new Date();
    const lastEarned = player.lastEarnedAt
      ? new Date(player.lastEarnedAt).getTime()
      : 0;
    if (now.getTime() - lastEarned < TAP_COOLDOWN_MS) {
      return NextResponse.json(
        { error: "Too fast! Slow down." },
        { status: 429 }
      );
    }

    const newCoins = (player.coins ?? 0) + TAP_AMOUNT;
    const newTotal = (player.totalCoinsEarned ?? 0) + TAP_AMOUNT;

    const [updated] = await db
      .update(players)
      .set({
        coins: newCoins,
        totalCoinsEarned: newTotal,
        lastEarnedAt: now,
        lastSavedAt: now,
      })
      .where(eq(players.id, playerId))
      .returning();

    return NextResponse.json({
      coins: updated.coins,
      totalCoinsEarned: updated.totalCoinsEarned,
      earned: TAP_AMOUNT,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
