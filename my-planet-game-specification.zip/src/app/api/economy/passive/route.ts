import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { players, buildingTicks } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { BUILDING_MAP } from "@/lib/buildings-data";

// POST /api/economy/passive  — collect passive income from buildings
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { playerId } = body;

    if (!playerId) {
      return NextResponse.json({ error: "playerId required" }, { status: 400 });
    }

    const [player] = await db
      .select()
      .from(players)
      .where(eq(players.id, playerId));

    if (!player) {
      return NextResponse.json({ error: "Player not found" }, { status: 404 });
    }

    const ownedBuildings = (player.ownedBuildings as string[]) ?? [];
    if (ownedBuildings.length === 0) {
      return NextResponse.json({ coins: player.coins, collected: 0 });
    }

    const now = new Date();
    let totalCollected = 0;
    const tickUpdates: Array<{ buildingId: string; lastTickAt: Date }> = [];

    for (const buildingId of ownedBuildings) {
      const def = BUILDING_MAP[buildingId];
      if (!def) continue;

      // Get last tick for this building
      const [tick] = await db
        .select()
        .from(buildingTicks)
        .where(
          and(
            eq(buildingTicks.playerId, playerId),
            eq(buildingTicks.buildingId, buildingId)
          )
        );

      const lastTick = tick ? new Date(tick.lastTickAt).getTime() : 0;
      const elapsed = now.getTime() - lastTick;
      const ticksElapsed = Math.floor(elapsed / (def.tickSeconds * 1000));

      if (ticksElapsed > 0) {
        // Cap at 10 ticks max (offline income cap)
        const cappedTicks = Math.min(ticksElapsed, 10);
        totalCollected += def.incomePerTick * cappedTicks;
        tickUpdates.push({ buildingId, lastTickAt: now });
      }
    }

    if (totalCollected === 0) {
      return NextResponse.json({ coins: player.coins, collected: 0 });
    }

    const newCoins = (player.coins ?? 0) + totalCollected;
    const newTotal = (player.totalCoinsEarned ?? 0) + totalCollected;

    // Update player coins
    const [updated] = await db
      .update(players)
      .set({
        coins: newCoins,
        totalCoinsEarned: newTotal,
        lastSavedAt: now,
      })
      .where(eq(players.id, playerId))
      .returning();

    // Update building ticks
    for (const { buildingId, lastTickAt } of tickUpdates) {
      const [existingTick] = await db
        .select()
        .from(buildingTicks)
        .where(
          and(
            eq(buildingTicks.playerId, playerId),
            eq(buildingTicks.buildingId, buildingId)
          )
        );

      if (existingTick) {
        await db
          .update(buildingTicks)
          .set({ lastTickAt })
          .where(
            and(
              eq(buildingTicks.playerId, playerId),
              eq(buildingTicks.buildingId, buildingId)
            )
          );
      } else {
        await db.insert(buildingTicks).values({
          playerId,
          buildingId,
          lastTickAt,
        });
      }
    }

    return NextResponse.json({
      coins: updated.coins,
      totalCoinsEarned: updated.totalCoinsEarned,
      collected: totalCollected,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
