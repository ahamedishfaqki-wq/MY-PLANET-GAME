import { NextResponse } from "next/server";
import { db } from "@/db";
import { players } from "@/db/schema";
import { desc } from "drizzle-orm";

// GET /api/leaderboard  — top players by coins
export async function GET() {
  try {
    const top = await db
      .select({
        id: players.id,
        username: players.username,
        coins: players.coins,
        totalCoinsEarned: players.totalCoinsEarned,
        place: players.place,
        ownedBuildings: players.ownedBuildings,
      })
      .from(players)
      .orderBy(desc(players.totalCoinsEarned))
      .limit(20);

    return NextResponse.json(top);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
