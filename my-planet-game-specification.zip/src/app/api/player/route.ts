import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { players } from "@/db/schema";
import { eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

// GET /api/player?id=xxx  or  /api/player?username=xxx
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  const username = searchParams.get("username");

  try {
    if (id) {
      const [player] = await db
        .select()
        .from(players)
        .where(eq(players.id, id));
      if (!player) {
        return NextResponse.json({ error: "Player not found" }, { status: 404 });
      }
      return NextResponse.json(player);
    }

    if (username) {
      const [player] = await db
        .select()
        .from(players)
        .where(eq(players.username, username));
      if (!player) {
        return NextResponse.json({ error: "Player not found" }, { status: 404 });
      }
      return NextResponse.json(player);
    }

    return NextResponse.json(
      { error: "Provide id or username" },
      { status: 400 }
    );
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/player  — create new player
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { username } = body;

    if (!username || typeof username !== "string" || username.trim().length < 2) {
      return NextResponse.json(
        { error: "Username must be at least 2 characters" },
        { status: 400 }
      );
    }

    // Check uniqueness
    const [existing] = await db
      .select()
      .from(players)
      .where(eq(players.username, username.trim()));
    if (existing) {
      return NextResponse.json(
        { error: "Username already taken" },
        { status: 409 }
      );
    }

    const id = uuidv4();
    const [newPlayer] = await db
      .insert(players)
      .values({
        id,
        username: username.trim(),
        coins: 500,
        totalCoinsEarned: 500,
        ownedBuildings: [],
        buildingLevels: {},
        place: "",
      })
      .returning();

    return NextResponse.json(newPlayer, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// PATCH /api/player  — update player state (character, place, etc.)
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: "id required" }, { status: 400 });
    }

    // Whitelist allowed fields
    const allowed: Record<string, unknown> = {};
    if (updates.characterBody !== undefined)
      allowed.characterBody = updates.characterBody;
    if (updates.characterHair !== undefined)
      allowed.characterHair = updates.characterHair;
    if (updates.characterOutfit !== undefined)
      allowed.characterOutfit = updates.characterOutfit;
    if (updates.characterAccessory !== undefined)
      allowed.characterAccessory = updates.characterAccessory;
    if (updates.place !== undefined) allowed.place = updates.place;
    if (updates.ownedBuildings !== undefined)
      allowed.ownedBuildings = updates.ownedBuildings;
    if (updates.buildingLevels !== undefined)
      allowed.buildingLevels = updates.buildingLevels;
    if (updates.coins !== undefined) allowed.coins = updates.coins;
    if (updates.totalCoinsEarned !== undefined)
      allowed.totalCoinsEarned = updates.totalCoinsEarned;

    allowed.lastSavedAt = new Date();

    const [updated] = await db
      .update(players)
      .set(allowed)
      .where(eq(players.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Player not found" }, { status: 404 });
    }

    return NextResponse.json(updated);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
