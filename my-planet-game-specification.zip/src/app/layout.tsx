import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "My Planet — Build · Live · Grow · Explore",
  description:
    "An idle city-builder where you earn coins, build from a small stall to a Mars colony. No levels — only coins!",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#0a0e2e] text-white antialiased">{children}</body>
    </html>
  );
}
