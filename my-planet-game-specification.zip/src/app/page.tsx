import GameShell from "@/components/GameShell";

export const metadata = {
  title: "My Planet — Build · Live · Grow · Explore",
  description:
    "An idle city-builder where you earn coins, build from a small stall to a Mars colony. No levels — only coins!",
};

export default function HomePage() {
  return <GameShell />;
}
