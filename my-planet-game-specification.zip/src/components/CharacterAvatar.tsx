"use client";

import { Character } from "@/lib/game-store";
import { CHARACTER_OPTIONS } from "@/lib/buildings-data";

interface Props {
  character: Character;
  size?: "sm" | "md" | "lg";
}

const BODY_COLORS: Record<string, string> = {
  base_a: "#F4C2A1",
  base_b: "#C68A5A",
  base_c: "#8D5524",
};

const HAIR_COLORS: Record<string, string> = {
  hair_01: "#1a1a1a",
  hair_02: "#8B4513",
  hair_03: "#2C1810",
  hair_04: "#4A2810",
};

const OUTFIT_COLORS: Record<string, string> = {
  outfit_01: "#3B82F6",
  outfit_02: "#1E3A5F",
  outfit_03: "#10B981",
  outfit_04: "#1a1a1a",
};

const HAIR_SHAPES: Record<string, string> = {
  hair_01: "M15,20 Q30,5 45,20 L45,18 Q30,2 15,18 Z",
  hair_02: "M10,20 Q20,2 40,5 Q50,8 50,20 L48,22 Q38,8 22,8 Q14,10 12,22 Z",
  hair_03: "M12,22 Q14,5 28,4 Q35,3 38,8 Q42,5 46,12 L44,18 Q40,8 36,12 Q32,6 28,8 Q18,8 16,22 Z",
  hair_04: "M10,18 Q15,2 30,3 Q45,2 50,18 L52,40 Q45,35 44,22 Q30,5 16,22 L14,40 Q12,35 10,18 Z",
};

export default function CharacterAvatar({ character, size = "md" }: Props) {
  const dim = size === "sm" ? 60 : size === "md" ? 100 : 150;
  const scale = dim / 100;

  const bodyColor = BODY_COLORS[character.body] ?? "#F4C2A1";
  const hairColor = HAIR_COLORS[character.hair] ?? "#1a1a1a";
  const outfitColor = OUTFIT_COLORS[character.outfit] ?? "#3B82F6";
  const hairShape = HAIR_SHAPES[character.hair] ?? HAIR_SHAPES.hair_01;

  const hairOption = CHARACTER_OPTIONS.hairs.find(
    (h) => h.id === character.hair
  );
  const outfitOption = CHARACTER_OPTIONS.outfits.find(
    (o) => o.id === character.outfit
  );
  const accessoryOption = CHARACTER_OPTIONS.accessories.find(
    (a) => a.id === character.accessory
  );

  return (
    <svg
      width={dim}
      height={dim}
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      style={{ display: "block" }}
    >
      {/* Body / Torso */}
      <ellipse cx="50" cy="72" rx="18" ry="22" fill={outfitColor} />

      {/* Neck */}
      <rect x="44" y="54" width="12" height="10" rx="4" fill={bodyColor} />

      {/* Head */}
      <ellipse cx="50" cy="45" rx="20" ry="22" fill={bodyColor} />

      {/* Hair */}
      <path d={hairShape} fill={hairColor} transform="translate(20,15)" />

      {/* Eyes */}
      <ellipse cx="44" cy="44" rx="3" ry="3.5" fill="white" />
      <ellipse cx="56" cy="44" rx="3" ry="3.5" fill="white" />
      <ellipse cx="44.5" cy="44.5" rx="1.8" ry="2" fill="#1a1a1a" />
      <ellipse cx="56.5" cy="44.5" rx="1.8" ry="2" fill="#1a1a1a" />
      {/* Eye shine */}
      <circle cx="45.5" cy="43.5" r="0.7" fill="white" />
      <circle cx="57.5" cy="43.5" r="0.7" fill="white" />

      {/* Eyebrows */}
      <path
        d="M41,40 Q44,38.5 47,40"
        stroke={hairColor}
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M53,40 Q56,38.5 59,40"
        stroke={hairColor}
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />

      {/* Nose */}
      <path
        d="M48,48 Q50,52 52,48"
        stroke={bodyColor}
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
        style={{ filter: "brightness(0.85)" }}
      />
      <ellipse cx="47" cy="50" rx="1.5" ry="1" fill={bodyColor} style={{ filter: "brightness(0.80)" }} />
      <ellipse cx="53" cy="50" rx="1.5" ry="1" fill={bodyColor} style={{ filter: "brightness(0.80)" }} />

      {/* Mouth / Smile */}
      <path
        d="M45,54 Q50,58 55,54"
        stroke="#C85A5A"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />

      {/* Arms */}
      <ellipse cx="32" cy="72" rx="7" ry="14" fill={outfitColor} />
      <ellipse cx="68" cy="72" rx="7" ry="14" fill={outfitColor} />
      {/* Hands */}
      <circle cx="32" cy="85" r="5" fill={bodyColor} />
      <circle cx="68" cy="85" r="5" fill={bodyColor} />

      {/* Accessory: Glasses */}
      {character.accessory === "glasses_01" && (
        <>
          <rect
            x="38"
            y="42"
            width="10"
            height="7"
            rx="3"
            fill="none"
            stroke="#1a1a1a"
            strokeWidth="1.5"
          />
          <rect
            x="52"
            y="42"
            width="10"
            height="7"
            rx="3"
            fill="none"
            stroke="#1a1a1a"
            strokeWidth="1.5"
          />
          <line x1="48" y1="45.5" x2="52" y2="45.5" stroke="#1a1a1a" strokeWidth="1.2" />
          <line x1="34" y1="45.5" x2="38" y2="45.5" stroke="#1a1a1a" strokeWidth="1.2" />
          <line x1="62" y1="45.5" x2="66" y2="45.5" stroke="#1a1a1a" strokeWidth="1.2" />
        </>
      )}

      {/* Accessory: Cap */}
      {character.accessory === "cap_01" && (
        <>
          <ellipse cx="50" cy="28" rx="22" ry="8" fill="#2563EB" />
          <path d="M28,28 Q50,18 72,28" fill="#1D4ED8" />
          {/* Brim */}
          <ellipse cx="50" cy="36" rx="22" ry="4" fill="#2563EB" />
          <rect x="28" y="32" width="44" height="4" fill="#2563EB" />
        </>
      )}

      {/* Accessory: Backpack */}
      {character.accessory === "backpack_01" && (
        <>
          <rect x="62" y="58" width="16" height="22" rx="4" fill="#DC2626" />
          <rect x="64" y="62" width="12" height="8" rx="2" fill="#EF4444" />
          <line x1="68" y1="57" x2="68" y2="58" stroke="#1a1a1a" strokeWidth="2" />
          <line x1="74" y1="57" x2="74" y2="58" stroke="#1a1a1a" strokeWidth="2" />
        </>
      )}
    </svg>
  );
}
