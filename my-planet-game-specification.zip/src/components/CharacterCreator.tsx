"use client";

import { useState } from "react";
import { useGameStore } from "@/lib/game-store";
import { CHARACTER_OPTIONS } from "@/lib/buildings-data";
import CharacterAvatar from "./CharacterAvatar";

export default function CharacterCreator() {
  const { player, setPlayer, setIsLoggedIn, setCurrentTab, showNotification } =
    useGameStore();
  const [username, setUsername] = useState(player.username || "");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const char = player.character;

  const updateChar = (field: keyof typeof char, value: string) => {
    setPlayer({ character: { ...char, [field]: value } });
  };

  const applyPreset = (preset: (typeof CHARACTER_OPTIONS.presets)[0]) => {
    setPlayer({
      character: {
        body: preset.body,
        hair: preset.hair,
        outfit: preset.outfit,
        accessory: preset.accessory,
      },
    });
  };

  const handleStart = async () => {
    if (!username.trim() || username.trim().length < 2) {
      setError("Username must be at least 2 characters");
      return;
    }
    setError("");
    setIsLoading(true);

    try {
      // Try to fetch existing player first
      const fetchRes = await fetch(
        `/api/player?username=${encodeURIComponent(username.trim())}`
      );

      if (fetchRes.ok) {
        const existing = await fetchRes.json();
        // Load existing player
        setPlayer({
          id: existing.id,
          username: existing.username,
          coins: existing.coins,
          totalCoinsEarned: existing.totalCoinsEarned,
          ownedBuildings: existing.ownedBuildings ?? [],
          buildingLevels: existing.buildingLevels ?? {},
          place: existing.place ?? "",
          character: {
            body: existing.characterBody,
            hair: existing.characterHair,
            outfit: existing.characterOutfit,
            accessory: existing.characterAccessory,
          },
        });
        setIsLoggedIn(true);
        setCurrentTab("city");
        showNotification(`Welcome back, ${existing.username}! 🎉`, "success");
        return;
      }

      // Create new player
      const createRes = await fetch("/api/player", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim() }),
      });

      if (!createRes.ok) {
        const err = await createRes.json();
        setError(err.error || "Failed to create player");
        return;
      }

      const newPlayer = await createRes.json();

      // Save character choices
      await fetch("/api/player", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: newPlayer.id,
          characterBody: char.body,
          characterHair: char.hair,
          characterOutfit: char.outfit,
          characterAccessory: char.accessory,
        }),
      });

      setPlayer({
        id: newPlayer.id,
        username: newPlayer.username,
        coins: newPlayer.coins,
        totalCoinsEarned: newPlayer.totalCoinsEarned,
        ownedBuildings: [],
        buildingLevels: {},
        character: char,
      });
      setIsLoggedIn(true);
      setCurrentTab("city");
      showNotification(`Welcome to My Planet, ${newPlayer.username}! 🚀`, "success");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 h-full">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-1">
          🌍 Create Your Character
        </h2>
        <p className="text-blue-200 text-sm">
          Pick a look and choose your username to start your journey!
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Preview */}
        <div className="flex flex-col items-center gap-4 bg-white/10 rounded-2xl p-6 min-w-[160px]">
          <div className="text-sm text-blue-200 font-medium mb-2">Preview</div>
          <div className="bg-gradient-to-b from-sky-400 to-blue-600 rounded-2xl p-4 shadow-xl">
            <CharacterAvatar character={char} size="lg" />
          </div>
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              {CHARACTER_OPTIONS.hairs.find((h) => h.id === char.hair)?.emoji}{" "}
              {CHARACTER_OPTIONS.hairs.find((h) => h.id === char.hair)?.label}
            </div>
            <div className="text-blue-200 text-xs">
              {
                CHARACTER_OPTIONS.outfits.find((o) => o.id === char.outfit)
                  ?.label
              }{" "}
              ·{" "}
              {
                CHARACTER_OPTIONS.accessories.find(
                  (a) => a.id === char.accessory
                )?.label
              }
            </div>
          </div>
        </div>

        {/* Customization */}
        <div className="flex-1 flex flex-col gap-4">
          {/* Presets */}
          <div>
            <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
              Quick Presets
            </div>
            <div className="flex gap-2 flex-wrap">
              {CHARACTER_OPTIONS.presets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset)}
                  className="flex flex-col items-center gap-1 bg-white/10 hover:bg-white/20 rounded-xl px-4 py-2 transition-all border border-white/10 hover:border-white/30"
                >
                  <span className="text-2xl">{preset.emoji}</span>
                  <span className="text-white text-xs font-medium">
                    {preset.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Hair */}
          <div>
            <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
              Hair Style
            </div>
            <div className="grid grid-cols-4 gap-2">
              {CHARACTER_OPTIONS.hairs.map((h) => (
                <button
                  key={h.id}
                  onClick={() => updateChar("hair", h.id)}
                  className={`flex flex-col items-center gap-1 rounded-xl px-2 py-2 transition-all border text-xs ${
                    char.hair === h.id
                      ? "bg-blue-500 border-blue-300 text-white shadow-lg shadow-blue-500/30"
                      : "bg-white/10 border-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  <span className="text-lg">{h.emoji}</span>
                  <span>{h.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Outfit */}
          <div>
            <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
              Outfit
            </div>
            <div className="grid grid-cols-4 gap-2">
              {CHARACTER_OPTIONS.outfits.map((o) => (
                <button
                  key={o.id}
                  onClick={() => updateChar("outfit", o.id)}
                  className={`flex flex-col items-center gap-1 rounded-xl px-2 py-2 transition-all border text-xs ${
                    char.outfit === o.id
                      ? "bg-blue-500 border-blue-300 text-white shadow-lg shadow-blue-500/30"
                      : "bg-white/10 border-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  <span className="text-lg">{o.emoji}</span>
                  <span>{o.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Accessories */}
          <div>
            <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
              Accessories
            </div>
            <div className="grid grid-cols-4 gap-2">
              {CHARACTER_OPTIONS.accessories.map((a) => (
                <button
                  key={a.id}
                  onClick={() => updateChar("accessory", a.id)}
                  className={`flex flex-col items-center gap-1 rounded-xl px-2 py-2 transition-all border text-xs ${
                    char.accessory === a.id
                      ? "bg-blue-500 border-blue-300 text-white shadow-lg shadow-blue-500/30"
                      : "bg-white/10 border-white/10 text-white/70 hover:bg-white/20"
                  }`}
                >
                  <span className="text-lg">{a.emoji}</span>
                  <span>{a.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Username + Start */}
          <div className="mt-2">
            <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
              Username
            </div>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleStart()}
              placeholder="Enter your username..."
              maxLength={20}
              className="w-full bg-white/10 text-white placeholder-white/40 border border-white/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:bg-white/15 transition-all"
            />
            {error && (
              <div className="text-red-400 text-xs mt-1">{error}</div>
            )}
          </div>

          <button
            onClick={handleStart}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 disabled:opacity-50 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg shadow-purple-500/30 text-sm"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="animate-spin">⏳</span> Starting...
              </span>
            ) : (
              "🚀 Start My Journey!"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
