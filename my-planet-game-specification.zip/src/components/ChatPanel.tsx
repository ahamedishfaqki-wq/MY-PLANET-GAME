"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useGameStore } from "@/lib/game-store";

interface ChatMessage {
  id: number;
  playerId: string;
  username: string;
  message: string;
  createdAt: string;
}

const CHAT_COLORS = [
  "text-blue-400",
  "text-purple-400",
  "text-green-400",
  "text-yellow-400",
  "text-pink-400",
  "text-cyan-400",
  "text-orange-400",
];

function getUserColor(username: string): string {
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash = username.charCodeAt(i) + ((hash << 5) - hash);
  }
  return CHAT_COLORS[Math.abs(hash) % CHAT_COLORS.length];
}

function formatTime(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
}

export default function ChatPanel() {
  const { player } = useGameStore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchMessages = useCallback(async () => {
    try {
      const res = await fetch("/api/chat?limit=50");
      if (res.ok) {
        const data = await res.json();
        setMessages(data);
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMessages();
    // Poll every 5 seconds for new messages
    pollRef.current = setInterval(fetchMessages, 5000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [fetchMessages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || !player.id || isSending) return;

    const text = input.trim();
    setInput("");
    setIsSending(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerId: player.id,
          username: player.username,
          message: text,
        }),
      });

      if (res.ok) {
        await fetchMessages();
      }
    } catch {
      setInput(text); // restore on error
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full gap-4">
      <div>
        <h2 className="text-2xl font-bold text-white mb-1">💬 Global Chat</h2>
        <p className="text-blue-200 text-sm">
          Chat with other players from around the world!
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 bg-black/20 rounded-2xl border border-white/10 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scroll">
          {isLoading ? (
            <div className="text-white/40 text-center text-sm py-8">
              Loading messages...
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-3">💬</div>
              <div className="text-white/50 text-sm">
                No messages yet. Be the first to say hi!
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.playerId === player.id;
              const colorClass = getUserColor(msg.username);

              return (
                <div
                  key={msg.id}
                  className={`flex gap-2 ${isMe ? "flex-row-reverse" : ""}`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                      isMe
                        ? "bg-blue-600"
                        : "bg-white/10"
                    }`}
                  >
                    {msg.username[0]?.toUpperCase()}
                  </div>

                  {/* Bubble */}
                  <div
                    className={`max-w-[75%] rounded-2xl px-3 py-2 ${
                      isMe
                        ? "bg-blue-600 rounded-tr-sm"
                        : "bg-white/10 rounded-tl-sm"
                    }`}
                  >
                    {!isMe && (
                      <div className={`text-xs font-bold mb-0.5 ${colorClass}`}>
                        {msg.username}
                      </div>
                    )}
                    <div className="text-white text-sm leading-snug">
                      {msg.message}
                    </div>
                    <div className="text-white/30 text-xs mt-0.5 text-right">
                      {formatTime(msg.createdAt)}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="border-t border-white/10 p-3 flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={player.id ? "Type a message..." : "Log in to chat"}
            disabled={!player.id || isSending}
            maxLength={200}
            className="flex-1 bg-white/10 text-white placeholder-white/30 border border-white/10 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400 disabled:opacity-40"
          />
          <button
            onClick={sendMessage}
            disabled={!input.trim() || !player.id || isSending}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl px-4 py-2 text-sm font-semibold transition-all"
          >
            {isSending ? "⏳" : "➤"}
          </button>
        </div>
      </div>

      {/* Online tip */}
      <div className="bg-white/5 rounded-xl p-3 text-center">
        <div className="text-white/40 text-xs">
          🌍 Chat refreshes every 5 seconds · Max 200 chars per message
        </div>
      </div>
    </div>
  );
}
