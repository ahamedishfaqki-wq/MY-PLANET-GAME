"use client";

import { useState, useCallback } from "react";
import { useGameStore } from "@/lib/game-store";
import {
  BUILDINGS,
  BuildingDef,
  formatCoins,
  canAfford,
  isBuildingUnlocked,
} from "@/lib/buildings-data";

function BuildingCard({
  building,
  owned,
  unlocked,
  affordable,
  onBuy,
  isBuying,
}: {
  building: BuildingDef;
  owned: boolean;
  unlocked: boolean;
  affordable: boolean;
  onBuy: (id: string) => void;
  isBuying: boolean;
}) {
  const isActive = owned;
  const canBuy = unlocked && affordable && !owned;
  const isLocked = !unlocked;

  return (
    <div
      className={`relative rounded-2xl border transition-all duration-300 overflow-hidden ${
        isActive
          ? "border-green-400/60 bg-gradient-to-br from-green-900/40 to-green-800/20 shadow-lg shadow-green-500/10"
          : isLocked
          ? "border-white/5 bg-white/5 opacity-50"
          : canBuy
          ? "border-yellow-400/40 bg-gradient-to-br from-yellow-900/30 to-orange-900/20 hover:border-yellow-400/70 cursor-pointer hover:shadow-lg hover:shadow-yellow-500/10"
          : "border-white/10 bg-white/5 opacity-70"
      }`}
    >
      {/* Owned badge */}
      {owned && (
        <div className="absolute top-2 right-2 bg-green-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
          ✓ Owned
        </div>
      )}

      {/* Tier badge */}
      {building.tier === "space" && (
        <div className="absolute top-2 left-2 bg-purple-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
          🚀 Space
        </div>
      )}

      <div className="p-4">
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div
            className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl flex-shrink-0 shadow-inner"
            style={{ backgroundColor: building.color + "33" }}
          >
            {isLocked ? "🔒" : building.emoji}
          </div>

          <div className="flex-1 min-w-0">
            <div className="font-bold text-white text-sm">
              {building.displayName}
            </div>
            <div className="text-white/60 text-xs mt-0.5 leading-tight">
              {isLocked
                ? `Requires: ${BUILDINGS.find((b) => b.buildingId === building.unlockRequiresBuildingId)?.displayName}`
                : building.description}
            </div>

            {/* Income info */}
            {!isLocked && (
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className="text-yellow-400 text-xs font-medium">
                  💰 +{formatCoins(building.incomePerTick)} / {building.tickSeconds}s
                </span>
                {owned && (
                  <span className="text-green-400 text-xs font-medium animate-pulse">
                    ● Active
                  </span>
                )}
              </div>
            )}

            {/* Cost */}
            {!owned && !isLocked && (
              <div className="flex items-center justify-between mt-3">
                <span
                  className={`text-sm font-bold ${
                    affordable ? "text-yellow-400" : "text-red-400"
                  }`}
                >
                  🪙 {formatCoins(building.cost)}
                </span>
                <button
                  onClick={() => canBuy && onBuy(building.buildingId)}
                  disabled={!canBuy || isBuying}
                  className={`text-xs font-bold px-3 py-1.5 rounded-lg transition-all ${
                    canBuy
                      ? "bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-white shadow-lg cursor-pointer"
                      : "bg-white/10 text-white/30 cursor-not-allowed"
                  }`}
                >
                  {isBuying ? "⏳" : canBuy ? "Build!" : "💸 Need more"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CityView() {
  const { player, setCoins, setOwnedBuildings, showNotification } =
    useGameStore();
  const [buyingId, setBuyingId] = useState<string | null>(null);
  const [filterTier, setFilterTier] = useState<"all" | "city" | "space">("all");

  const ownedBuildings = player.ownedBuildings ?? [];
  const buildingLevels = player.buildingLevels ?? {};

  const handleBuy = useCallback(
    async (buildingId: string) => {
      if (!player.id || buyingId) return;
      setBuyingId(buildingId);

      try {
        const res = await fetch("/api/economy/buy", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ playerId: player.id, buildingId }),
        });

        const data = await res.json();
        if (!res.ok) {
          showNotification(data.error || "Purchase failed", "error");
          return;
        }

        setCoins(data.coins, player.totalCoinsEarned);
        setOwnedBuildings(
          data.ownedBuildings as string[],
          data.buildingLevels as Record<string, number>
        );

        const building = BUILDINGS.find((b) => b.buildingId === buildingId);
        showNotification(
          `🎉 ${building?.displayName} built! Earning +${formatCoins(building?.incomePerTick ?? 0)}/tick`,
          "success"
        );
      } catch {
        showNotification("Network error. Try again.", "error");
      } finally {
        setBuyingId(null);
      }
    },
    [player.id, player.totalCoinsEarned, buyingId, setCoins, setOwnedBuildings, showNotification]
  );

  const filteredBuildings = BUILDINGS.filter(
    (b) => filterTier === "all" || b.tier === filterTier
  );

  const ownedCount = ownedBuildings.length;
  const totalIncome = ownedBuildings.reduce((sum, id) => {
    const b = BUILDINGS.find((b) => b.buildingId === id);
    if (!b) return sum;
    return sum + b.incomePerTick * (60 / b.tickSeconds);
  }, 0);

  return (
    <div className="flex flex-col gap-4 h-full">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-1">🌆 Your City</h2>
        <p className="text-blue-200 text-sm">
          Build your empire — from a tiny stall to a Mars colony!
        </p>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white/10 rounded-xl p-3 text-center">
          <div className="text-yellow-400 text-lg font-bold">{ownedCount}</div>
          <div className="text-white/60 text-xs">Buildings</div>
        </div>
        <div className="bg-white/10 rounded-xl p-3 text-center">
          <div className="text-green-400 text-lg font-bold">
            +{formatCoins(Math.round(totalIncome))}/min
          </div>
          <div className="text-white/60 text-xs">Passive Income</div>
        </div>
        <div className="bg-white/10 rounded-xl p-3 text-center">
          <div className="text-purple-400 text-lg font-bold">
            {formatCoins(player.coins ?? 0)}
          </div>
          <div className="text-white/60 text-xs">Balance</div>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(["all", "city", "space"] as const).map((tier) => (
          <button
            key={tier}
            onClick={() => setFilterTier(tier)}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              filterTier === tier
                ? "bg-blue-500 text-white"
                : "bg-white/10 text-white/60 hover:bg-white/20"
            }`}
          >
            {tier === "all" ? "🏙️ All" : tier === "city" ? "🌆 City" : "🚀 Space"}
          </button>
        ))}
      </div>

      {/* Buildings grid */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-3 custom-scroll">
        {filteredBuildings.map((building) => {
          const owned = ownedBuildings.includes(building.buildingId);
          const unlocked = isBuildingUnlocked(building, ownedBuildings);
          const affordable = canAfford(player.coins ?? 0, building.cost);

          return (
            <BuildingCard
              key={building.buildingId}
              building={building}
              owned={owned}
              unlocked={unlocked}
              affordable={affordable}
              onBuy={handleBuy}
              isBuying={buyingId === building.buildingId}
            />
          );
        })}
      </div>

      {/* City scene visual */}
      <div className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 rounded-xl p-4 border border-white/10">
        <div className="text-xs text-white/50 mb-2 font-medium">Your City Skyline</div>
        <div className="flex items-end gap-1 h-16 overflow-x-auto">
          {ownedBuildings.length === 0 ? (
            <div className="text-white/30 text-xs italic w-full text-center py-4">
              Build your first building to see your city grow!
            </div>
          ) : (
            ownedBuildings.map((id) => {
              const b = BUILDINGS.find((b) => b.buildingId === id);
              const idx = BUILDINGS.findIndex((b) => b.buildingId === id);
              const height = Math.min(16 + idx * 6, 60);
              return (
                <div
                  key={id}
                  className="flex flex-col items-center gap-0.5 flex-shrink-0"
                  title={b?.displayName}
                >
                  <span className="text-base">{b?.emoji}</span>
                  <div
                    style={{
                      width: 20,
                      height,
                      backgroundColor: b?.color + "88",
                      borderRadius: "3px 3px 0 0",
                      border: `1px solid ${b?.color}66`,
                    }}
                  />
                </div>
              );
            })
          )}
        </div>
        {/* Ground */}
        <div className="h-1 bg-gradient-to-r from-green-600 to-green-700 rounded mt-0" />
      </div>
    </div>
  );
}
