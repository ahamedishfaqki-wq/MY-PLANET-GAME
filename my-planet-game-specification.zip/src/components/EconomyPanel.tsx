"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useGameStore } from "@/lib/game-store";
import { BUILDINGS, formatCoins } from "@/lib/buildings-data";

const JOBS = [
  { id: "freelance", label: "Freelance Work", emoji: "💻", earn: 10, cooldown: 0 },
  { id: "delivery", label: "Food Delivery", emoji: "🛵", earn: 15, cooldown: 2000 },
  { id: "tutoring", label: "Tutoring", emoji: "📚", earn: 25, cooldown: 5000 },
  { id: "consulting", label: "Consulting", emoji: "📊", earn: 50, cooldown: 10000 },
];

export default function EconomyPanel() {
  const { player, setCoins, showNotification } = useGameStore();
  const [tapCooldown, setTapCooldown] = useState(false);
  const [passiveMsg, setPassiveMsg] = useState("");
  const [tapEffect, setTapEffect] = useState(false);
  const [jobCooldowns, setJobCooldowns] = useState<Record<string, number>>({});
  const passiveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Collect passive income every 30 seconds
  const collectPassive = useCallback(async () => {
    if (!player.id) return;
    try {
      const res = await fetch("/api/economy/passive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: player.id }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.collected > 0) {
          setCoins(data.coins, data.totalCoinsEarned);
          setPassiveMsg(`+${formatCoins(data.collected)} passive income!`);
          setTimeout(() => setPassiveMsg(""), 3000);
        }
      }
    } catch {
      // silently fail
    }
  }, [player.id, setCoins]);

  useEffect(() => {
    if (!player.id) return;
    collectPassive();
    passiveIntervalRef.current = setInterval(collectPassive, 30000);
    return () => {
      if (passiveIntervalRef.current) clearInterval(passiveIntervalRef.current);
    };
  }, [player.id, collectPassive]);

  const handleTapEarn = async () => {
    if (tapCooldown || !player.id) return;
    setTapCooldown(true);
    setTapEffect(true);
    setTimeout(() => setTapEffect(false), 300);

    try {
      const res = await fetch("/api/economy/earn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: player.id }),
      });

      if (res.ok) {
        const data = await res.json();
        setCoins(data.coins, data.totalCoinsEarned);
      }
    } catch {
      // ignore
    } finally {
      setTimeout(() => setTapCooldown(false), 600);
    }
  };

  const handleJobAction = async (job: (typeof JOBS)[0]) => {
    if (!player.id || jobCooldowns[job.id]) return;

    // Set cooldown
    if (job.cooldown > 0) {
      setJobCooldowns((prev) => ({ ...prev, [job.id]: job.cooldown }));
      const interval = setInterval(() => {
        setJobCooldowns((prev) => {
          const remaining = (prev[job.id] ?? 0) - 100;
          if (remaining <= 0) {
            clearInterval(interval);
            const next = { ...prev };
            delete next[job.id];
            return next;
          }
          return { ...prev, [job.id]: remaining };
        });
      }, 100);
    }

    // Use the main earn endpoint
    try {
      const res = await fetch("/api/economy/earn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: player.id }),
      });

      if (res.ok) {
        const data = await res.json();
        setCoins(data.coins, data.totalCoinsEarned);
        showNotification(
          `${job.emoji} +${data.earned} coins from ${job.label}!`,
          "success"
        );
      }
    } catch {
      // ignore
    }
  };

  const ownedBuildings = player.ownedBuildings ?? [];
  const totalPassivePerMin = ownedBuildings.reduce((sum, id) => {
    const b = BUILDINGS.find((b) => b.buildingId === id);
    if (!b) return sum;
    return sum + b.incomePerTick * (60 / b.tickSeconds);
  }, 0);

  const progressToNextMilestone = () => {
    const milestones = [
      500, 5000, 10000, 50000, 500000, 5000000, 50000000, 500000000,
      1000000000, 5000000000,
    ];
    const coins = player.totalCoinsEarned ?? 0;
    const next = milestones.find((m) => m > coins);
    if (!next) return { label: "🏆 Max!", pct: 100, next: 0, current: coins };
    const prev = milestones[milestones.indexOf(next) - 1] ?? 0;
    const pct = Math.min(((coins - prev) / (next - prev)) * 100, 100);
    return { label: formatCoins(next), pct, next, current: coins };
  };

  const milestone = progressToNextMilestone();

  return (
    <div className="flex flex-col gap-5 h-full">
      <div>
        <h2 className="text-2xl font-bold text-white mb-1">💰 Economy</h2>
        <p className="text-blue-200 text-sm">
          Work, earn, and grow your coin empire!
        </p>
      </div>

      {/* Balance card */}
      <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-2xl p-5 text-center">
        <div className="text-yellow-300/70 text-xs font-semibold uppercase tracking-wider mb-1">
          Current Balance
        </div>
        <div className="text-4xl font-black text-yellow-400 mb-1">
          🪙 {formatCoins(player.coins ?? 0)}
        </div>
        <div className="text-white/40 text-xs">
          Total earned: {formatCoins(player.totalCoinsEarned ?? 0)}
        </div>
        {passiveMsg && (
          <div className="mt-2 text-green-400 text-sm font-semibold animate-bounce">
            {passiveMsg}
          </div>
        )}
      </div>

      {/* Tap to earn */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center">
        <div className="text-white/70 text-xs mb-3">
          Quick tap to earn coins instantly!
        </div>
        <button
          onClick={handleTapEarn}
          disabled={tapCooldown}
          className={`w-24 h-24 mx-auto rounded-full flex flex-col items-center justify-center transition-all duration-150 shadow-xl font-bold text-white ${
            tapCooldown
              ? "bg-gray-600 scale-95 opacity-60"
              : "bg-gradient-to-br from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 active:scale-95 hover:shadow-yellow-500/40"
          } ${tapEffect ? "scale-90" : "scale-100"}`}
        >
          <span className="text-3xl">💼</span>
          <span className="text-xs mt-1">+10</span>
        </button>
        <div className="text-white/40 text-xs mt-2">Tap to work</div>
      </div>

      {/* Jobs */}
      <div>
        <div className="text-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
          Job Actions
        </div>
        <div className="grid grid-cols-2 gap-2">
          {JOBS.map((job) => {
            const cdMs = jobCooldowns[job.id] ?? 0;
            const isOnCd = cdMs > 0;
            const cdPct = isOnCd ? (cdMs / job.cooldown) * 100 : 0;

            return (
              <button
                key={job.id}
                onClick={() => handleJobAction(job)}
                disabled={isOnCd}
                className={`relative overflow-hidden rounded-xl p-3 flex flex-col items-center gap-1 transition-all text-center border ${
                  isOnCd
                    ? "border-white/5 bg-white/5 opacity-60 cursor-wait"
                    : "border-white/10 bg-white/10 hover:bg-white/20 hover:border-white/20 cursor-pointer"
                }`}
              >
                {isOnCd && (
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-blue-500 transition-all"
                    style={{ width: `${cdPct}%` }}
                  />
                )}
                <span className="text-2xl">{job.emoji}</span>
                <span className="text-white text-xs font-semibold">
                  {job.label}
                </span>
                <span className="text-yellow-400 text-xs">+{job.earn} coins</span>
                {isOnCd && (
                  <span className="text-white/40 text-xs">
                    {(cdMs / 1000).toFixed(1)}s
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Passive income */}
      <div className="bg-green-900/20 border border-green-500/20 rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-green-400 text-sm font-semibold">
            📈 Passive Income
          </div>
          <div className="text-green-300 font-bold text-sm">
            +{formatCoins(Math.round(totalPassivePerMin))}/min
          </div>
        </div>
        <div className="text-white/40 text-xs">
          {ownedBuildings.length === 0
            ? "Build your first building in the City tab to start earning passively!"
            : `${ownedBuildings.length} building${ownedBuildings.length !== 1 ? "s" : ""} working for you 24/7`}
        </div>
      </div>

      {/* Progress */}
      <div className="bg-white/5 rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-white/70 text-xs font-semibold">
            Next Milestone
          </div>
          <div className="text-white/50 text-xs">{milestone.label}</div>
        </div>
        <div className="h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
            style={{ width: `${milestone.pct}%` }}
          />
        </div>
        <div className="text-white/30 text-xs mt-1">
          {formatCoins(milestone.current)} / {milestone.label}
        </div>
      </div>
    </div>
  );
}
