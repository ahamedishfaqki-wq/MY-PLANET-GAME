"use client";

import { useEffect, useCallback, useRef } from "react";
import { useGameStore, GameTab } from "@/lib/game-store";
import { formatCoins } from "@/lib/buildings-data";
import CharacterCreator from "./CharacterCreator";
import CityView from "./CityView";
import EconomyPanel from "./EconomyPanel";
import ChatPanel from "./ChatPanel";
import LeaderboardPanel from "./LeaderboardPanel";
import CharacterAvatar from "./CharacterAvatar";

const TABS: { id: GameTab; label: string; emoji: string }[] = [
  { id: "character", label: "Character", emoji: "🧑" },
  { id: "city", label: "City", emoji: "🌆" },
  { id: "economy", label: "Economy", emoji: "💰" },
  { id: "chat", label: "Chat", emoji: "💬" },
  { id: "leaderboard", label: "Ranks", emoji: "🏆" },
];

export default function GameShell() {
  const {
    player,
    currentTab,
    isLoggedIn,
    notification,
    setCurrentTab,
    clearNotification,
    setCoins,
    logout,
  } = useGameStore();

  const notifTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (notification) {
      if (notifTimer.current) clearTimeout(notifTimer.current);
      notifTimer.current = setTimeout(clearNotification, 3500);
    }
    return () => {
      if (notifTimer.current) clearTimeout(notifTimer.current);
    };
  }, [notification, clearNotification]);

  // Quick earn - also available from top bar
  const handleQuickEarn = async () => {
    if (!player.id) return;
    try {
      const res = await fetch("/api/economy/earn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: player.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setCoins(data.coins, data.totalCoinsEarned);
      }
    } catch {
      // ignore
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0e2e] via-[#0d1847] to-[#0a1628] flex flex-col">
      {/* ─── Header ─── */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="text-2xl">🌍</span>
            <div>
              <div className="text-white font-black text-lg leading-none">
                My Planet
              </div>
              <div className="text-blue-300/70 text-xs leading-none">
                Build · Live · Grow
              </div>
            </div>
          </div>

          <div className="flex-1" />

          {isLoggedIn && (
            <>
              {/* Coin balance */}
              <button
                onClick={handleQuickEarn}
                className="flex items-center gap-2 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/30 rounded-xl px-3 py-1.5 transition-all group"
                title="Tap to earn +10 coins"
              >
                <span className="text-lg">🪙</span>
                <span className="text-yellow-400 font-bold text-sm">
                  {formatCoins(player.coins ?? 0)}
                </span>
                <span className="text-yellow-500/50 text-xs group-hover:text-yellow-400 transition-all">
                  +10
                </span>
              </button>

              {/* Player badge */}
              <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-1.5">
                <CharacterAvatar character={player.character} size="sm" />
                <div className="hidden sm:block">
                  <div className="text-white text-xs font-semibold leading-none">
                    {player.username}
                  </div>
                  <div className="text-white/40 text-xs leading-none mt-0.5">
                    {player.ownedBuildings?.length ?? 0} buildings
                  </div>
                </div>
              </div>

              {/* Logout */}
              <button
                onClick={logout}
                className="text-white/40 hover:text-white/70 text-xs transition-all px-2"
                title="Logout"
              >
                ✕
              </button>
            </>
          )}
        </div>
      </header>

      {/* ─── Hero banner (only on character tab / not logged in) ─── */}
      {!isLoggedIn && (
        <div
          className="relative overflow-hidden border-b border-white/10"
          style={{ minHeight: 140 }}
        >
          <div
            className="absolute inset-0 bg-cover bg-center opacity-30"
            style={{ backgroundImage: "url('/images/hero-bg.jpg')" }}
          />
          <div className="relative max-w-5xl mx-auto px-4 py-8 flex items-center gap-6">
            <div>
              <h1 className="text-3xl sm:text-4xl font-black text-white leading-tight">
                My Planet 🌍🚀
              </h1>
              <p className="text-blue-200 text-sm mt-1 max-w-md">
                Build your city, earn coins, reach Mars. No levels — only coins.
              </p>
              <div className="flex gap-3 mt-3 text-xs text-white/60">
                <span>👥 3 Characters</span>
                <span>🏪 10 Buildings</span>
                <span>🚀 Mars Colony</span>
                <span>💬 Multiplayer Chat</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── Main content ─── */}
      <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-6 flex flex-col gap-4">
        {/* Notification */}
        {notification && (
          <div
            className={`rounded-xl px-4 py-3 text-sm font-medium flex items-center gap-2 shadow-lg transition-all ${
              notification.type === "success"
                ? "bg-green-900/60 border border-green-500/40 text-green-300"
                : notification.type === "error"
                ? "bg-red-900/60 border border-red-500/40 text-red-300"
                : "bg-blue-900/60 border border-blue-500/40 text-blue-300"
            }`}
          >
            {notification.type === "success" && "✅ "}
            {notification.type === "error" && "❌ "}
            {notification.type === "info" && "ℹ️ "}
            {notification.message}
          </div>
        )}

        {/* Tab navigation (only when logged in) */}
        {isLoggedIn && (
          <nav className="flex gap-1 bg-white/5 p-1 rounded-2xl overflow-x-auto custom-scroll-x">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all flex-shrink-0 ${
                  currentTab === tab.id
                    ? "bg-blue-600 text-white shadow-lg"
                    : "text-white/60 hover:text-white hover:bg-white/10"
                }`}
              >
                <span>{tab.emoji}</span>
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </nav>
        )}

        {/* Tab content */}
        <div className="flex-1 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-5 overflow-hidden">
          {!isLoggedIn || currentTab === "character" ? (
            <CharacterCreator />
          ) : currentTab === "city" ? (
            <CityView />
          ) : currentTab === "economy" ? (
            <EconomyPanel />
          ) : currentTab === "chat" ? (
            <ChatPanel />
          ) : currentTab === "leaderboard" ? (
            <LeaderboardPanel />
          ) : null}
        </div>

        {/* Footer info bar (logged in) */}
        {isLoggedIn && (
          <div className="flex items-center justify-between text-xs text-white/30 px-2">
            <span>🌍 My Planet MVP · No levels — only coins</span>
            <span>
              Earth → Space → Mars{" "}
              {(player.ownedBuildings ?? []).includes("mars_colony") && "✅"}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
