"use client";

import { useState, useEffect, useCallback } from "react";
import { useGameStore } from "@/lib/game-store";
import { formatCoins } from "@/lib/buildings-data";

interface LeaderEntry {
  id: string;
  username: string;
  coins: number;
  totalCoinsEarned: number;
  place: string;
  ownedBuildings: string[];
}

const MEDALS = ["🥇", "🥈", "🥉"];

const PLACES = [
  "Kerala", "Tamil Nadu", "Karnataka", "Maharashtra",
  "Delhi", "Mumbai", "Bangalore", "Chennai",
  "Hyderabad", "Kolkata", "Pune", "Ahmedabad",
];

export default function LeaderboardPanel() {
  const { player, setPlayer, showNotification } = useGameStore();
  const [leaders, setLeaders] = useState<LeaderEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPlace, setSelectedPlace] = useState(player.place || "");
  const [isSavingPlace, setIsSavingPlace] = useState(false);

  const fetchLeaderboard = useCallback(async () => {
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        setLeaders(data);
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLeaderboard();
    const interval = setInterval(fetchLeaderboard, 15000);
    return () => clearInterval(interval);
  }, [fetchLeaderboard]);

  const savePlace = async () => {
    if (!player.id || !selectedPlace) return;
    setIsSavingPlace(true);
    try {
      const res = await fetch("/api/player", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: player.id, place: selectedPlace }),
      });
      if (res.ok) {
        setPlayer({ place: selectedPlace });
        showNotification(`📍 Location set to ${selectedPlace}!`, "success");
        fetchLeaderboard();
      }
    } catch {
      showNotification("Failed to save location", "error");
    } finally {
      setIsSavingPlace(false);
    }
  };

  const myRank =
    leaders.findIndex((l) => l.id === player.id) + 1 || "—";

  return (
    <div className="flex flex-col gap-4 h-full">
      <div>
        <h2 className="text-2xl font-bold text-white mb-1">🏆 Leaderboard</h2>
        <p className="text-blue-200 text-sm">
          Top players ranked by total coins ever earned
        </p>
      </div>

      {/* My rank card */}
      <div className="bg-gradient-to-r from-purple-900/40 to-blue-900/40 rounded-xl border border-purple-500/20 p-4">
        <div className="flex items-center gap-4">
          <div className="text-3xl font-black text-purple-300">
            #{myRank}
          </div>
          <div className="flex-1">
            <div className="text-white font-bold">{player.username || "—"}</div>
            <div className="text-white/50 text-xs">
              {formatCoins(player.totalCoinsEarned ?? 0)} total earned ·{" "}
              {player.ownedBuildings?.length ?? 0} buildings
            </div>
          </div>
          <div className="text-yellow-400 text-xl font-bold">
            🪙 {formatCoins(player.coins ?? 0)}
          </div>
        </div>
      </div>

      {/* Set location */}
      <div className="bg-white/5 rounded-xl p-3 flex gap-2">
        <select
          value={selectedPlace}
          onChange={(e) => setSelectedPlace(e.target.value)}
          className="flex-1 bg-white/10 text-white border border-white/10 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-blue-400"
        >
          <option value="">📍 Set your location...</option>
          {PLACES.map((p) => (
            <option key={p} value={p} className="bg-gray-800">
              {p}
            </option>
          ))}
        </select>
        <button
          onClick={savePlace}
          disabled={!selectedPlace || isSavingPlace || !player.id}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-semibold px-4 py-1.5 rounded-lg transition-all"
        >
          {isSavingPlace ? "..." : "Save"}
        </button>
      </div>

      {/* Leaderboard list */}
      <div className="flex-1 overflow-y-auto space-y-2 custom-scroll">
        {isLoading ? (
          <div className="text-white/40 text-center py-8 text-sm">
            Loading rankings...
          </div>
        ) : leaders.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-4xl mb-3">🏆</div>
            <div className="text-white/50 text-sm">
              No players yet — you could be #1!
            </div>
          </div>
        ) : (
          leaders.map((entry, idx) => {
            const isMe = entry.id === player.id;
            const medal = MEDALS[idx] ?? null;

            return (
              <div
                key={entry.id}
                className={`flex items-center gap-3 rounded-xl px-4 py-3 border transition-all ${
                  isMe
                    ? "bg-blue-600/20 border-blue-500/40"
                    : "bg-white/5 border-white/5 hover:bg-white/10"
                }`}
              >
                {/* Rank */}
                <div className="w-8 text-center">
                  {medal ? (
                    <span className="text-xl">{medal}</span>
                  ) : (
                    <span className="text-white/40 text-sm font-bold">
                      #{idx + 1}
                    </span>
                  )}
                </div>

                {/* Avatar letter */}
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                    isMe ? "bg-blue-500" : "bg-white/10"
                  }`}
                >
                  {entry.username[0]?.toUpperCase()}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="text-white text-sm font-semibold truncate">
                      {entry.username}
                    </span>
                    {isMe && (
                      <span className="text-blue-300 text-xs">(you)</span>
                    )}
                  </div>
                  <div className="text-white/40 text-xs">
                    {entry.place || "Unknown"} ·{" "}
                    {(entry.ownedBuildings as string[])?.length ?? 0} buildings
                  </div>
                </div>

                {/* Coins */}
                <div className="text-right flex-shrink-0">
                  <div className="text-yellow-400 text-sm font-bold">
                    🪙 {formatCoins(entry.totalCoinsEarned)}
                  </div>
                  <div className="text-white/30 text-xs">
                    {formatCoins(entry.coins)} now
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="text-center text-white/30 text-xs">
        Refreshes every 15 seconds · Ranked by total coins earned
      </div>
    </div>
  );
}
