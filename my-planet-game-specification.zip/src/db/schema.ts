import {
  pgTable,
  text,
  bigint,
  timestamp,
  jsonb,
  boolean,
  integer,
  serial,
} from "drizzle-orm/pg-core";

// Players table
export const players = pgTable("players", {
  id: text("id").primaryKey(),
  username: text("username").notNull().unique(),
  characterBody: text("character_body").notNull().default("base_a"),
  characterHair: text("character_hair").notNull().default("hair_01"),
  characterOutfit: text("character_outfit").notNull().default("outfit_01"),
  characterAccessory: text("character_accessory").notNull().default("none"),
  coins: bigint("coins", { mode: "number" }).notNull().default(500),
  totalCoinsEarned: bigint("total_coins_earned", { mode: "number" })
    .notNull()
    .default(500),
  ownedBuildings: jsonb("owned_buildings")
    .$type<string[]>()
    .notNull()
    .default([]),
  buildingLevels: jsonb("building_levels")
    .$type<Record<string, number>>()
    .notNull()
    .default({}),
  place: text("place").notNull().default(""),
  lastEarnedAt: timestamp("last_earned_at").notNull().defaultNow(),
  lastSavedAt: timestamp("last_saved_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  playerId: text("player_id")
    .notNull()
    .references(() => players.id, { onDelete: "cascade" }),
  username: text("username").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Passive income log (for tracking when buildings last ticked)
export const buildingTicks = pgTable("building_ticks", {
  id: serial("id").primaryKey(),
  playerId: text("player_id")
    .notNull()
    .references(() => players.id, { onDelete: "cascade" }),
  buildingId: text("building_id").notNull(),
  lastTickAt: timestamp("last_tick_at").notNull().defaultNow(),
});

export type Player = typeof players.$inferSelect;
export type NewPlayer = typeof players.$inferInsert;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type NewChatMessage = typeof chatMessages.$inferInsert;
