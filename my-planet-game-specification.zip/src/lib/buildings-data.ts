export interface BuildingDef {
  buildingId: string;
  displayName: string;
  emoji: string;
  description: string;
  cost: number;
  unlockRequiresBuildingId: string | null;
  incomePerTick: number;
  tickSeconds: number;
  tier: "city" | "space";
  nextBuildingId: string | null;
  color: string;
}

export const BUILDINGS: BuildingDef[] = [
  {
    buildingId: "small_stall",
    displayName: "Small Stall",
    emoji: "🏪",
    description: "A tiny market stall. Every empire starts somewhere!",
    cost: 500,
    unlockRequiresBuildingId: null,
    incomePerTick: 5,
    tickSeconds: 30,
    tier: "city",
    nextBuildingId: "restaurant",
    color: "#f59e0b",
  },
  {
    buildingId: "restaurant",
    displayName: "Restaurant",
    emoji: "🍽️",
    description: "A bustling local eatery. Customers love the food!",
    cost: 5000,
    unlockRequiresBuildingId: "small_stall",
    incomePerTick: 25,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "shop_store",
    color: "#ef4444",
  },
  {
    buildingId: "shop_store",
    displayName: "Shop / Store",
    emoji: "🏬",
    description: "A proper retail store serving the whole neighborhood.",
    cost: 10000,
    unlockRequiresBuildingId: "restaurant",
    incomePerTick: 60,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "hotel",
    color: "#8b5cf6",
  },
  {
    buildingId: "hotel",
    displayName: "Hotel",
    emoji: "🏨",
    description: "Five star hospitality in your growing city.",
    cost: 50000,
    unlockRequiresBuildingId: "shop_store",
    incomePerTick: 200,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "bus_stand",
    color: "#06b6d4",
  },
  {
    buildingId: "bus_stand",
    displayName: "Bus Stand",
    emoji: "🚌",
    description: "Public transport hub connecting the city.",
    cost: 500000,
    unlockRequiresBuildingId: "hotel",
    incomePerTick: 800,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "railway",
    color: "#10b981",
  },
  {
    buildingId: "railway",
    displayName: "Railway Station",
    emoji: "🚉",
    description: "A major railway hub. The city grows around it.",
    cost: 5000000,
    unlockRequiresBuildingId: "bus_stand",
    incomePerTick: 3000,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "metro",
    color: "#3b82f6",
  },
  {
    buildingId: "metro",
    displayName: "Metro System",
    emoji: "🚇",
    description: "Underground metro — your city is truly modern now!",
    cost: 50000000,
    unlockRequiresBuildingId: "railway",
    incomePerTick: 12000,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "city_expansion",
    color: "#6366f1",
  },
  {
    buildingId: "city_expansion",
    displayName: "City Expansion",
    emoji: "🌆",
    description: "Expand city limits. A metropolis in the making!",
    cost: 500000000,
    unlockRequiresBuildingId: "metro",
    incomePerTick: 50000,
    tickSeconds: 60,
    tier: "city",
    nextBuildingId: "spacex_facility",
    color: "#f97316",
  },
  {
    buildingId: "spacex_facility",
    displayName: "SpaceX Facility",
    emoji: "🚀",
    description: "Launch rockets. The stars are within reach!",
    cost: 1000000000,
    unlockRequiresBuildingId: "city_expansion",
    incomePerTick: 250000,
    tickSeconds: 60,
    tier: "space",
    nextBuildingId: "mars_colony",
    color: "#ec4899",
  },
  {
    buildingId: "mars_colony",
    displayName: "Mars Colony",
    emoji: "🔴",
    description: "You've colonized Mars. Humanity's future secured!",
    cost: 5000000000,
    unlockRequiresBuildingId: "spacex_facility",
    incomePerTick: 1000000,
    tickSeconds: 60,
    tier: "space",
    nextBuildingId: null,
    color: "#dc2626",
  },
];

export const BUILDING_MAP: Record<string, BuildingDef> = Object.fromEntries(
  BUILDINGS.map((b) => [b.buildingId, b])
);

export const CHARACTER_OPTIONS = {
  bodies: [
    { id: "base_a", label: "Body A", emoji: "🧑" },
    { id: "base_b", label: "Body B", emoji: "👧" },
    { id: "base_c", label: "Body C", emoji: "🧑‍🦱" },
  ],
  hairs: [
    { id: "hair_01", label: "Short", emoji: "💇" },
    { id: "hair_02", label: "Wavy", emoji: "👱" },
    { id: "hair_03", label: "Curly", emoji: "👩‍🦱" },
    { id: "hair_04", label: "Long", emoji: "👩‍🦰" },
  ],
  outfits: [
    { id: "outfit_01", label: "Casual", emoji: "👕" },
    { id: "outfit_02", label: "Formal", emoji: "👔" },
    { id: "outfit_03", label: "Sporty", emoji: "🧥" },
    { id: "outfit_04", label: "Cool", emoji: "🥼" },
  ],
  accessories: [
    { id: "none", label: "None", emoji: "—" },
    { id: "glasses_01", label: "Glasses", emoji: "🕶️" },
    { id: "cap_01", label: "Cap", emoji: "🧢" },
    { id: "backpack_01", label: "Backpack", emoji: "🎒" },
  ],
  presets: [
    {
      id: "boy",
      label: "Boy",
      emoji: "👦",
      body: "base_a",
      hair: "hair_01",
      outfit: "outfit_01",
      accessory: "none",
    },
    {
      id: "girl",
      label: "Girl",
      emoji: "👧",
      body: "base_b",
      hair: "hair_04",
      outfit: "outfit_01",
      accessory: "none",
    },
    {
      id: "cool",
      label: "Cool Style",
      emoji: "😎",
      body: "base_c",
      hair: "hair_02",
      outfit: "outfit_04",
      accessory: "glasses_01",
    },
  ],
};

export function formatCoins(n: number): string {
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(2) + "B";
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return n.toLocaleString();
}

export function canAfford(coins: number, cost: number): boolean {
  return coins >= cost;
}

export function isBuildingUnlocked(
  building: BuildingDef,
  ownedBuildings: string[]
): boolean {
  if (!building.unlockRequiresBuildingId) return true;
  return ownedBuildings.includes(building.unlockRequiresBuildingId);
}
