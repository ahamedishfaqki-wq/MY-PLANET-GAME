"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface Character {
  body: string;
  hair: string;
  outfit: string;
  accessory: string;
}

export interface PlayerState {
  id: string | null;
  username: string;
  character: Character;
  coins: number;
  totalCoinsEarned: number;
  ownedBuildings: string[];
  buildingLevels: Record<string, number>;
  place: string;
  lastSavedAt: string | null;
}

export type GameTab = "character" | "city" | "economy" | "chat" | "leaderboard";

interface GameStore {
  player: PlayerState;
  currentTab: GameTab;
  isLoggedIn: boolean;
  isSaving: boolean;
  notification: { message: string; type: "success" | "error" | "info" } | null;

  // Actions
  setPlayer: (player: Partial<PlayerState>) => void;
  setCoins: (coins: number, totalCoinsEarned?: number) => void;
  setOwnedBuildings: (buildings: string[], levels: Record<string, number>) => void;
  setCurrentTab: (tab: GameTab) => void;
  setIsLoggedIn: (v: boolean) => void;
  setIsSaving: (v: boolean) => void;
  showNotification: (message: string, type: "success" | "error" | "info") => void;
  clearNotification: () => void;
  logout: () => void;
}

const DEFAULT_PLAYER: PlayerState = {
  id: null,
  username: "",
  character: {
    body: "base_a",
    hair: "hair_01",
    outfit: "outfit_01",
    accessory: "none",
  },
  coins: 500,
  totalCoinsEarned: 500,
  ownedBuildings: [],
  buildingLevels: {},
  place: "",
  lastSavedAt: null,
};

export const useGameStore = create<GameStore>()(
  persist(
    (set) => ({
      player: DEFAULT_PLAYER,
      currentTab: "character",
      isLoggedIn: false,
      isSaving: false,
      notification: null,

      setPlayer: (updates) =>
        set((state) => ({
          player: { ...state.player, ...updates },
        })),

      setCoins: (coins, totalCoinsEarned) =>
        set((state) => ({
          player: {
            ...state.player,
            coins,
            totalCoinsEarned:
              totalCoinsEarned ?? state.player.totalCoinsEarned,
          },
        })),

      setOwnedBuildings: (buildings, levels) =>
        set((state) => ({
          player: {
            ...state.player,
            ownedBuildings: buildings,
            buildingLevels: levels,
          },
        })),

      setCurrentTab: (tab) => set({ currentTab: tab }),
      setIsLoggedIn: (v) => set({ isLoggedIn: v }),
      setIsSaving: (v) => set({ isSaving: v }),

      showNotification: (message, type) =>
        set({ notification: { message, type } }),

      clearNotification: () => set({ notification: null }),

      logout: () =>
        set({
          player: DEFAULT_PLAYER,
          isLoggedIn: false,
          currentTab: "character",
        }),
    }),
    {
      name: "my-planet-game-state",
      partialize: (state) => ({
        player: state.player,
        isLoggedIn: state.isLoggedIn,
        currentTab: state.currentTab,
      }),
    }
  )
);
